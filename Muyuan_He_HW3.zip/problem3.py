import numpy as np
import math as m
import matplotlib.pyplot as plt
import sys

### part c
dt = [0.5, 0.1, 0.05, 0.01, 0.005, 0.001]
list1 = [[0.5], [0], [-0.25]] #init value
#list1 = [[], [], []]
def f1(w, v, a):
    return [[v],[a], [(1-6*w)*v] ]
def f2(w, v, a): 
    return f1(w+tau/2*f1(w,v,a)[0][0], v+ tau/2* f1(w,v,a)[1][0], a+tau/2*f1(w, v, a)[2][0])
def f3(w, v, a):
    return f2(w+tau/2*f2(w,v,a)[0][0], v+ tau/2* f2(w,v,a)[1][0], a+tau/2*f2(w, v, a)[2][0])
def f4(w, v, a):
    return f3(w+tau*f3(w,v,a)[0][0],v+ f3(w,v,a)[1][0], a+ f3(w,v,a)[2][0])

def exact(z):
    return(0.5*(1/m.cosh(z/2))**2)
#list2 = np.arange(0, 10, 0.5).tolist()
#index = list2.index(5.0)

#print(index)
#["foo", "bar", "baz"].index("bar")
list3 = []
list4 = []
iterlist = np.arange(0, 5, 0.01).tolist()
tau = 0.01
# want w
for item in iterlist:
    list1[0][0] = list1[0][0]+(tau/6)*(f1(list1[0][0], list1[1][0], list1[2][0])[0][0]+f2(list1[0][0], list1[1][0], list1[2][0])[0][0]*2+\
                                                   f3(list1[0][0], list1[1][0], list1[2][0])[0][0]*2 + f4(list1[0][0], list1[1][0], list1[2][0])[0][0])
    list1[1][0] = list1[1][0]+(tau/6)*(f1(list1[0][0], list1[1][0], list1[2][0])[1][0]+f2(list1[0][0], list1[1][0], list1[2][0])[1][0]*2+\
                                                   f3(list1[0][0], list1[1][0], list1[2][0])[1][0]*2 + f4(list1[0][0], list1[1][0], list1[2][0])[1][0])
    list1[2][0] = list1[2][0]+(tau/6)*(f1(list1[0][0], list1[1][0], list1[2][0])[2][0]+f2(list1[0][0], list1[1][0], list1[2][0])[2][0]*2+\
                                                   f3(list1[0][0], list1[1][0], list1[2][0])[2][0]*2 + f4(list1[0][0], list1[1][0], list1[2][0])[2][0])
    list3.append(list1[0][0])
    list4.append(exact(item))

    
plt.figure(1)
plt.plot(iterlist, list3)
plt.plot(iterlist, list4)
plt.title("rk4_KdV")
plt.xlabel("z")
plt.ylabel("w")
plt.show()

### part d





list3 = []
list4 = []
iterlist = np.arange(0, 50, 0.01).tolist()
tau = 0.01
# want w
for item in iterlist:
    list1[0][0] = list1[0][0]+(tau/6)*(f1(list1[0][0], list1[1][0], list1[2][0])[0][0]+f2(list1[0][0], list1[1][0], list1[2][0])[0][0]*2+\
                                                   f3(list1[0][0], list1[1][0], list1[2][0])[0][0]*2 + f4(list1[0][0], list1[1][0], list1[2][0])[0][0])
    list1[1][0] = list1[1][0]+(tau/6)*(f1(list1[0][0], list1[1][0], list1[2][0])[1][0]+f2(list1[0][0], list1[1][0], list1[2][0])[1][0]*2+\
                                                   f3(list1[0][0], list1[1][0], list1[2][0])[1][0]*2 + f4(list1[0][0], list1[1][0], list1[2][0])[1][0])
    list1[2][0] = list1[2][0]+(tau/6)*(f1(list1[0][0], list1[1][0], list1[2][0])[2][0]+f2(list1[0][0], list1[1][0], list1[2][0])[2][0]*2+\
                                                   f3(list1[0][0], list1[1][0], list1[2][0])[2][0]*2 + f4(list1[0][0], list1[1][0], list1[2][0])[2][0])
    list3.append(list1[0][0])
    list4.append(exact(item))

    
plt.figure(2)
plt.plot(iterlist, list3)
plt.plot(iterlist, list4)
plt.title("rk4_KdV")
plt.xlabel("z")
plt.ylabel("w")
plt.show()


