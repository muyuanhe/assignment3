import numpy as np
import math as m
import matplotlib.pyplot as plt
import sys

### Problem 2(b)
# Verlet Method

g1 = np.zeros(6)
y1 = [0, 0, 0, 0, 0, 0]
x1 = [0, 0, 0, 0, 0, 0]
dt = np.array([0.5, 0.1, 0.05, 0.01, 0.005, 0.001])
hahalist = [8, 40, 80, 400, 800, 4000] #THis list will determine which when is T=5
for item in range(6):
    #print(item)
    N = 5000
    arr1 = np.arange(N)
    r = np.zeros(N)
    v = np.ones(N)
    t = np.arange(start=1, stop=N+1, step=dt[item])
    t = t[0:N]
    a = np.zeros(N)

    for i in np.nditer(arr1[0:N-1]):
        if i == 0:
            a[i] = -r[i]
            r[i+1] = v[i]*dt[item] 
            v[i] = (r[i+1] -0)/(2*dt[item])
        else:
            a[i] = -r[i]
            r[i+1] = 2*r[i] - r[i-1] +dt[item]**2*a[i]
            v[i] = (r[i+1]- r[i-1])/(2*dt[item])
    #haha = 0
    #hahalist = []
    #hahalist = list(t)
    #for j in range(len(hahalist)):
    #    if t[j] == 5.0:
    #        haha = j
    #print(t)
    #print(r)
    #print("haha! n_th term with T=5: ", haha, " for step equals ", dt[item])
    #print("x_verlet(T) = ", r[haha])
    #print(item)
    #print("here", hahalist[item])
    g1[item] = abs(m.sin(5)-r[hahalist[item]])
    #print(m.log(g1[item]))
    y1[item] = m.log(g1[item])
    x1[item] = m.log(dt[item])
    
    #t_location = np.where(t == 5.0) 
    #print("x_verlet at T = 6 is: ", r[t_location])  
plt.figure(1)
plt.plot(y1, x1)
plt.title("g1(delta_t)")
plt.xlabel("delta_t")
plt.ylabel("abs(sin(T)-x_verlet(T))")
plt.show()
"""
# RK4 Method
# Set two functions: f(x), g(x); dx/dt = v, dv/dt = a = x''= -x; x0 = 0, v0 = 1
dt = [0.5, 0.1, 0.05, 0.01, 0.005, 0.001]
tau = 0.5 #global
def F1(x, v):
    L1 = [[v], [-1*x]]
    return L1
def F2(x, v):
    return F1(x+tau/2*F1(x,v)[0][0], v+ tau/2* F1(x,v)[1][0])
def F3(x, v):
    return F2(x+tau/2*F2(x,v)[0][0], v+ tau/2* F2(x,v)[1][0])
def F4(x, v):
    return F3(x+tau*F3(x,v)[0][0],v+ F3(x,v)[1][0])

x_v_list = [[0], [1]]
#hahalist = [8, 40, 80, 400, 800, 4000]
hahalist = [1, 2, 2, 2, 2, 2]
for i in range(len(dt)):
    tau = dt[i]
    print("i", i)
    for j in range(hahalist[i]):
        #print("F1", F1(x_v_list[0][0], x_v_list[1][0])[0][0], "\n")
        #print("F2", F2(x_v_list[0][0], x_v_list[1][0])[0][0], "\n")
        #print("F3", F3(x_v_list[0][0], x_v_list[1][0])[0][0], "\n")
        #print("F4", F4(x_v_list[0][0], x_v_list[1][0])[0][0], "\n")
        x_v_list[0][0] = x_v_list[0][0]+(tau/6)*(F1(x_v_list[0][0], x_v_list[1][0])[0][0]+F2(x_v_list[0][0], x_v_list[1][0])[0][0]*2+\
                                                   F3(x_v_list[0][0], x_v_list[1][0])[0][0]*2 + F4(x_v_list[0][0], x_v_list[1][0])[0][0])
        print(x_v_list)
        x_v_list[1][0] = x_v_list[1][0]+(tau/6)*(F1(x_v_list[0][0], x_v_list[1][0])[1][0]+F2(x_v_list[0][0], x_v_list[1][0])[1][0]*2+\
                                                   F3(x_v_list[0][0], x_v_list[1][0])[1][0]*2 + F4(x_v_list[0][0], x_v_list[1][0])[1][0])
        print(x_v_list)

"""

