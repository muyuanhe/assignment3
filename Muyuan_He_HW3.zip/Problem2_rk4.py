import numpy as np
import math as m
import matplotlib.pyplot as plt
import sys

dt = [0.5, 0.1, 0.05, 0.01, 0.005, 0.001]
tau = 0.5 #global
def F1(x, v):
    L1 = [[v], [-1*x]]
    return L1
def F2(x, v):
    return F1(x+tau/2*F1(x,v)[0][0], v+ tau/2* F1(x,v)[1][0])
def F3(x, v):
    return F2(x+tau/2*F2(x,v)[0][0], v+ tau/2* F2(x,v)[1][0])
def F4(x, v):
    return F3(x+tau*F3(x,v)[0][0],v+ F3(x,v)[1][0])

x_v_list = [[0], [1]]
hahalist = [8, 40, 80, 400, 800, 4000]
#hahalist = [1, 2, 2, 2, 2, 2]
for i in range(len(dt)):
    tau = dt[i]
    print("i", i)
    for j in range(hahalist[i]):
        #print("F1", F1(x_v_list[0][0], x_v_list[1][0])[0][0], "\n")
        #print("F2", F2(x_v_list[0][0], x_v_list[1][0])[0][0], "\n")
        #print("F3", F3(x_v_list[0][0], x_v_list[1][0])[0][0], "\n")
        #print("F4", F4(x_v_list[0][0], x_v_list[1][0])[0][0], "\n")
        x_v_list[0][0] = x_v_list[0][0]+(tau/6)*(F1(x_v_list[0][0], x_v_list[1][0])[0][0]+F2(x_v_list[0][0], x_v_list[1][0])[0][0]*2+\
                                                   F3(x_v_list[0][0], x_v_list[1][0])[0][0]*2 + F4(x_v_list[0][0], x_v_list[1][0])[0][0])
        #print(x_v_list)
        x_v_list[1][0] = x_v_list[1][0]+(tau/6)*(F1(x_v_list[0][0], x_v_list[1][0])[1][0]+F2(x_v_list[0][0], x_v_list[1][0])[1][0]*2+\
                                                   F3(x_v_list[0][0], x_v_list[1][0])[1][0]*2 + F4(x_v_list[0][0], x_v_list[1][0])[1][0])
        #print(x_v_list)

